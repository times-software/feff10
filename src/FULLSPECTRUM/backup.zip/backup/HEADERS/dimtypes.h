      integer nclusx,nspx,natx,nattx,lx,nphx,ltot,nrptx,nex,lamtot
      integer mtot, ntot, npatx, legtot, novrx, nheadx
