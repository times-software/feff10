      real pi, third, one, zero, raddeg,fa,bohr,hart,alpinv
      real ryd, alphfs
      complex*16 coni
