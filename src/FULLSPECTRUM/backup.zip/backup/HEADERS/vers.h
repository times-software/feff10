      character*12 vfeff
c                       123456789012  
      parameter (vfeff='Feff 8.20   ')
