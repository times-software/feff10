      integer mxedgs, maxpts, fullpts, lmax, nexts, nlog, numcnv,vfeff
      real econv, ecnv, bigemax, bigemin
      character*8 infile
      real khi, klo, delta, minres, trsize, xkstep

