Some intermediate files for the Compton module (compton_info.bin and g0_*.bin)
are quite large (hundreds of megs), and thus have not been included in
REFERENCE.zip

A reference including these files is available at:
http://www.phys.washington.edu/~bmattern/feff/Compton_Cu_REFERENCE_FULL.zip


